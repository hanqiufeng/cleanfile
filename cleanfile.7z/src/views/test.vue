<template>
  <div>
    这是test
  </div>
</template>
<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import { Route } from 'vue-router';
@Component({
  components: {},
})
export default class Test extends Vue {
  
}
</script>
<style lang="scss" scoped></style>
