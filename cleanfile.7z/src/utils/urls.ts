export const urls: object = {
    
};

export default urls;
