<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style lang="scss">
@import "assets/scss/base.scss";
@import "assets/scss/element_myset.scss";
</style>
